package com.example.nytimes;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.nytimes.adapters.ArticlesListAdapter;
import com.example.nytimes.connection.Services;
import com.example.nytimes.models.ArticlesModel;
import com.pnikosis.materialishprogress.ProgressWheel;

import butterknife.BindView;
import io.reactivex.disposables.CompositeDisposable;

public class MainActivity extends AppCompatActivity implements Services.OnResponseReceived {

    @BindView(R.id.articles_rv) RecyclerView articlesRecyclerView ;
    @BindView(R.id.progress_wheel) ProgressWheel progressWheel ;

    private CompositeDisposable compositeDisposable ;

    private Services services ;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        callArticlesApi();
    }

    private void init() {
        setUpRecyclerView();
        setUpConnection();
    }

    private void setUpRecyclerView() {
        articlesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setUpConnection() {
        compositeDisposable = new CompositeDisposable();
        services = new Services(this, this);
    }

    private void callArticlesApi() {
        String apiKey = "zZTKiAWakVWh5GWLPHIK3LZsAEOaagE3";
        services.getArticlesList(compositeDisposable, apiKey, progressWheel);
    }
    @Override
    public void onResponse(boolean isSuccess, String flag, Object model) {
        ArticlesModel articlesModel = (ArticlesModel) model;
        if (articlesModel.getStatus().equals("OK")){
            ArticlesListAdapter articlesListAdapter = new ArticlesListAdapter(this, articlesModel.getResults());
            articlesRecyclerView.setAdapter(articlesListAdapter);
        }
    }
}

package com.example.nytimes.connection;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;

import com.example.nytimes.utils.Utils;
import com.pnikosis.materialishprogress.ProgressWheel;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * Authored by Emad Mohamed on 30 MAy, 2018.
 * Contact: emad.3oon@gmail.com
 * Aziz by Phorous.com © 2018.
 */

public class Services {

    private Activity context;
    private OnResponseReceived responseReceived;
    private Validator validator;

    public Services(Activity context, OnResponseReceived responseReceived) {
        this.context = context;
        this.responseReceived = responseReceived;
        validator = new Validator(context, responseReceived);
    }

    @SuppressLint("CheckResult")
    public void getArticlesList(CompositeDisposable disposables, String apiKey,
                                ProgressWheel progressWheel) {
        if (isConnected()) {
            APIService apiService = RetroConnect.getRetrofitInstance().create(APIService.class);
            apiService.getArticlesList(apiKey)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe(disposable -> {
                        progressWheel.setVisibility(View.VISIBLE);
                        disposables.add(disposable);
                    })
//                    .doOnComplete(hideProgress(progressWheel))
                    .subscribe(articlesModel -> validator.validateResponse(
                            articlesModel,
                            APIUrls.FLAGS.FLAG_ARTICLES_LIST
                            ), throwable -> {
                                progressWheel.setVisibility(View.GONE);
                                onFail(throwable);
                            }
                    );

        }
    }


    private void showProgress(ProgressWheel wheel) {
        if (wheel != null) {
            wheel.setVisibility(View.VISIBLE);
        }
    }

    private void hideProgress(ProgressWheel wheel) {
        if (wheel != null) {
            wheel.setVisibility(View.GONE);
        }
    }

    private boolean isConnected() {
        return Utils.isNetworkAvailable(context, true);
    }

    private void onFail(@NonNull Throwable t) {
        responseReceived.onResponse(false, APIUrls.FLAGS.FLAG_SERVER_ERROR, null);
        Log.e("response", t.toString());
    }

    /**
     * Interface to pass service response when arrived.
     */
    public interface OnResponseReceived {

        /**
         * Pass model filled with data from the service
         *
         * @param isSuccess true if response is completely success
         * @param flag      name of called service to receive the right one when this method called
         */
        void onResponse(boolean isSuccess, String flag, Object model);
    }


    private RequestBody createPart(Object data) {
        return RequestBody.create(MultipartBody.FORM, String.valueOf(data));
    }
}

package com.example.nytimes.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.nytimes.R;
import com.example.nytimes.models.ArticlesModel;

import java.util.List;

import butterknife.BindView;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Emad Mohamed Oun on 3/24/2019.
 * Rytalo
 * e.oun@rytalo.com
 */

public class ArticlesListAdapter extends RecyclerView.Adapter<ArticlesListAdapter.MyViewHolder> {

    private Context context;
    private List<ArticlesModel.ResultsDataModel> articlesList;

    public ArticlesListAdapter(Context context,
                               List<ArticlesModel.ResultsDataModel> articlesList) {
        this.context = context;
        this.articlesList = articlesList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_articles, parent, false);

        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        fillViewWithData(holder, position);
    }

    @SuppressLint({"SetTextI18n", "ResourceType"})
    private void fillViewWithData(MyViewHolder holder, int position) {
        ArticlesModel.ResultsDataModel articleData = articlesList.get(position);
        holder.articleTitleTextView.setText(articleData.getTitle());
        holder.articleDescriptionTextView.setText(articleData.getAbstractX());
        holder.authorNameTextView.setText(articleData.getSource());
        holder.articleDateTextView.setText(articleData.getPublished_date());
    }

    @Override
    public int getItemCount() {
        return articlesList.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.article_iv)
        CircleImageView articleImageView;
        @BindView(R.id.article_title_tv)
        TextView articleTitleTextView;
        @BindView(R.id.article_description_tv)
        TextView articleDescriptionTextView;
        @BindView(R.id.author_name_tv)
        TextView authorNameTextView;
        @BindView(R.id.article_date_tv)
        TextView articleDateTextView;

        MyViewHolder(View itemView) {
            super(itemView);

        }
    }

}

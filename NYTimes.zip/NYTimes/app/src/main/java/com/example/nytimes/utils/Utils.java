package com.example.nytimes.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;
import com.example.nytimes.R;

/**
 * Created by Emad Mohamed Oun on 3/24/2019.
 * Rytalo
 * e.oun@rytalo.com
 */
public class Utils {
    /**
     * Check if network available of not
     *
     * @return true if is available
     */
    public static boolean isNetworkAvailable(final Context context, boolean showToast) {
        if (context != null) {
            ConnectivityManager mConnectivity =
                    (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mNetworkInfo = null;
            if (mConnectivity != null) {
                mNetworkInfo = mConnectivity.getActiveNetworkInfo();
            }
            boolean isNetworkAvailable = mNetworkInfo != null && mNetworkInfo.isConnectedOrConnecting();
            if (!isNetworkAvailable && showToast) {
                Toast.makeText(context, context.getString(R.string.no_internet), Toast.LENGTH_SHORT).show();
            }
            return isNetworkAvailable;
        } else {
            return false;
        }
    }
}
